# <YOUR_IMPORTS>
import json
import pickle
import os
from datetime import datetime

import dill
import pandas as pd

path = os.environ.get('PROJECT_PATH', '..')

def predict():
    # <YOUR_CODE>
    #model = os.listdir(f'{path}/data/models')
    with open(f'{path}/data/models/cars_pipe_202407241701.pkl', 'rb') as f:
        model_from_pickle = dill.load(f)

    df_pred = pd.DataFrame(columns=['car_id', 'pred'])
    test_list = os.listdir(f'{path}/data/test')

    for fn in test_list:
        with open(f'{path}/data/test/{fn}') as file:
            form = json.load(file)

            data = pd.DataFrame.from_dict([form])
            pr = model_from_pickle.predict(data)
            dict_pred = {'car_id': data.id, 'pred': pr}
            df = pd.DataFrame(dict_pred)
            df_pred = pd.concat([df_pred, df], axis = 0)

    df_pred.to_csv(f'{path}/data/predictions/preds_{datetime.now().strftime("%Y%m%d%H%M")}.csv', index=False)
    pass


if __name__ == '__main__':
    predict()
